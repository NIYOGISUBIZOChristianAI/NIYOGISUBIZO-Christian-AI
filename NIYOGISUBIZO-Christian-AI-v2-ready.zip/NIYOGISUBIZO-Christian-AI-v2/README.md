# NIYOGISUBIZO Christian AI v2

A simple educational AI website/PWA for studying, questions, translation and notes.

## Vercel deployment
1. Upload the project files to the root of your GitHub repository.
2. Import the repository into Vercel.
3. In Vercel Project Settings → Environment Variables, add `OPENAI_API_KEY` for Production, Preview and Development.
4. Redeploy the project.
5. Open the deployed website and test a question.

**Security:** Never put the OpenAI API key in `index.html`, GitHub, or other browser code. The key belongs only in Vercel Environment Variables.

The `/api/chat` endpoint calls the OpenAI Responses API from the server, keeping the secret key out of the browser.

## Android
The website is PWA-ready and can be installed from a compatible mobile browser. For a Play Store APK/AAB, the next step is wrapping this web app with an Android WebView/TWA project.
