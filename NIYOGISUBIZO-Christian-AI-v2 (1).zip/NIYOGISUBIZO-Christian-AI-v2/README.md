# NIYOGISUBIZO Christian AI v2

This version adds a secure Vercel serverless backend.

## Important
The OpenAI API key must NOT be placed in `index.html` or committed to GitHub.

Add `OPENAI_API_KEY` as a Vercel Environment Variable for Production, Preview, and Development, then redeploy.

The frontend sends questions to `/api/chat`; the server uses the secret key to call the OpenAI Responses API.
