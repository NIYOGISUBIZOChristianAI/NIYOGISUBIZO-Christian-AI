export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed." });
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: "AI backend is not configured yet. Add OPENAI_API_KEY in Vercel Environment Variables." });
  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    const question = String(body?.question || "").trim();
    if (!question) return res.status(400).json({ error: "Please enter a question." });
    if (question.length > 8000) return res.status(400).json({ error: "Please make the question shorter." });
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST", headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
      body: JSON.stringify({ model: "gpt-5.4-mini", instructions: "You are NIYOGISUBIZO Christian AI, a friendly educational assistant. Help students study, understand subjects, answer questions, translate languages, and create clear notes. Explain step by step when useful. Be accurate and age-appropriate. When a question is about the Rwanda school curriculum, prefer clear school-level explanations.", input: question, max_output_tokens: 1200 })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data?.error?.message || "The AI provider returned an error." });
    const answer = data.output_text || data.output?.flatMap(item => item.content || [])?.map(part => part.text || "")?.join("") || "I could not generate an answer.";
    return res.status(200).json({ answer });
  } catch (error) { return res.status(500).json({ error: "Server error while contacting the AI." }); }
}
